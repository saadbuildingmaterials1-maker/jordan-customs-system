Jordan Customs System - Windows Build v2.5.0

تعليمات التثبيت:
1. فك ضغط الملف
2. قم بتشغيل bin/start.sh
3. سيتم فتح التطبيق تلقائياً
