Jordan Customs System - Windows Build v2.5.0

Installation Instructions:
1. Extract this folder
2. Run setup.exe
3. Follow the installation wizard
