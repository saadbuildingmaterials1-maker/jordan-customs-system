Jordan Customs System - Linux Build v2.5.0

Installation Instructions:
1. Extract this folder
2. Run ./install.sh
3. Follow the installation wizard
