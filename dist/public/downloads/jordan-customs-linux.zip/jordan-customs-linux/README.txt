Jordan Customs System - Linux Build v2.5.0

Installation Instructions:
1. Extract this folder
2. Run ./bin/start.sh
3. The app will start automatically
