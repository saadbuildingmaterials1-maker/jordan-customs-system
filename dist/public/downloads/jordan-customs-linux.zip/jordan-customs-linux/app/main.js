const { app, BrowserWindow } = require('electron');
app.on('ready', () => { console.log('App started'); });
