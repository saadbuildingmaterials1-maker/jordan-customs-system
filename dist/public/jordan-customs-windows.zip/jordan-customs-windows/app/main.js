Main application file
