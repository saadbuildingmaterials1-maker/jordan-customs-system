# Jordan Customs System - Windows PowerShell Startup Script
# This script starts the Jordan Customs application on Windows using PowerShell

Write-Host ""
Write-Host "====================================" -ForegroundColor Cyan
Write-Host "Jordan Customs System - Windows" -ForegroundColor Cyan
Write-Host "====================================" -ForegroundColor Cyan
Write-Host ""

# Check if Node.js is installed
$nodeCheck = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCheck) {
    Write-Host "Error: Node.js is not installed or not in PATH" -ForegroundColor Red
    Write-Host "Please install Node.js from https://nodejs.org/" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Display Node.js version
Write-Host "Node.js version:" -ForegroundColor Green
node --version
Write-Host ""

# Check if npm is installed
$npmCheck = Get-Command npm -ErrorAction SilentlyContinue
if (-not $npmCheck) {
    Write-Host "Error: npm is not installed or not in PATH" -ForegroundColor Red
    Write-Host "Please install npm with Node.js" -ForegroundColor Yellow
    Read-Host "Press Enter to exit"
    exit 1
}

# Display npm version
Write-Host "npm version:" -ForegroundColor Green
npm --version
Write-Host ""

# Install dependencies if node_modules doesn't exist
if (-not (Test-Path "node_modules")) {
    Write-Host "Installing dependencies..." -ForegroundColor Yellow
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Error: Failed to install dependencies" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
}

# Start the application
Write-Host ""
Write-Host "Starting Jordan Customs System..." -ForegroundColor Green
Write-Host "Application will open at: http://localhost:3000" -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop the application" -ForegroundColor Yellow
Write-Host ""

npm start

Read-Host "Press Enter to exit"
