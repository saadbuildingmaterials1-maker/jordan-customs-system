Jordan Customs System - Windows Edition
نظام إدارة تكاليف الشحن والجمارك الأردنية - إصدار Windows

QUICK START:
1. Double-click start.bat to run the application
2. Open your browser and go to http://localhost:3000

For detailed instructions, see INSTALLATION_GUIDE_WINDOWS.txt

البدء السريع:
1. انقر مرتين على start.bat لتشغيل التطبيق
2. افتح المتصفح وانتقل إلى http://localhost:3000

للمزيد من التعليمات، اقرأ INSTALLATION_GUIDE_WINDOWS.txt
