Jordan Customs System - Linux Edition
نظام إدارة تكاليف الشحن والجمارك الأردنية - إصدار Linux

QUICK START:
1. Open Terminal
2. Navigate to this folder
3. Run: chmod +x start.sh && ./start.sh
4. Open your browser and go to http://localhost:3000
